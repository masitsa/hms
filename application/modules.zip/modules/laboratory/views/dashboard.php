<div class="row">
    <div class="col-md-6">
    <?php echo $this->load->view('nurse/dashboard/queue_chart', '', TRUE);?>
    </div>
    <div class="col-md-6">
    <?php echo $this->load->view('nurse/dashboard/queue_summary', '', TRUE);?>
    </div>
</div>