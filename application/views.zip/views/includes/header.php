
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <!-- Title and other stuffs -->
  <title>SUMC | <?php echo $title;?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">


  <!-- Stylesheets -->
  <link href="<?php echo base_url()."assets/bluish/"?>style/bootstrap.css" rel="stylesheet">
  <!-- Font awesome icon -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/font-awesome.css"> 
  <!-- jQuery UI -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/jquery-ui.css"> 
  <!-- Calendar -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/fullcalendar.css">
  <!-- prettyPhoto -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/prettyPhoto.css">   
  <!-- Star rating -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/rateit.css">
  <!-- Date picker -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/bootstrap-datetimepicker.min.css">
  <!-- jQuery Gritter -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/jquery.gritter.css">
  <!-- CLEditor -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/jquery.cleditor.css"> 
  <!-- Bootstrap toggle -->
  <link rel="stylesheet" href="<?php echo base_url()."assets/bluish/"?>style/bootstrap-switch.css">
    <!-- Horizontal scroll -->
    <link href="<?php echo base_url()."assets/bluish/"?>style/jquery.horizontal.scroll.css" rel="stylesheet">
    <!-- Main stylesheet -->
  <link href="<?php echo base_url()."assets/bluish/"?>style/style.css" rel="stylesheet">
  <!-- Widgets stylesheet -->
  <link href="<?php echo base_url()."assets/bluish/"?>style/widgets.css" rel="stylesheet">
    <!-- Slim slidebar stylesheet -->
    <link href="<?php echo base_url()."assets/bluish/"?>style/slim_style.css" rel="stylesheet">
  
  
  <!-- HTML5 Support for IE -->
  <!--[if lt IE 9]>
  <script src="<?php echo base_url()."assets/bluish/"?>js/html5shim.js"></script>
  <![endif]-->

  <!-- Favicon -->
  <link rel="shortcut icon" href="img/favicon/favicon.png">
<script src="<?php echo base_url()."assets/bluish/"?>js/jquery.js"></script> <!-- jQuery -->