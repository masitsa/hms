
		</div>
	</div>
	
	<div id="footer">
		<p>Copyright &copy; 2012 Sitename.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org">james brian studio</a>.</p>
	</div>
</body>
</html>